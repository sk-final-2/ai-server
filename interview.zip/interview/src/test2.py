from interview.predict_keepgoing import keepgoing

print(keepgoing("배고플땐 뭘 먹을까요","너가 알아서 하세요"))