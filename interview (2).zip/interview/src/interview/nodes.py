from interview.model import InterviewState
from langchain_core.prompts import ChatPromptTemplate
from utils.chroma_qa import get_similar_question, save_answer, save_question
from utils.chroma_setup import reset_interview
from langchain_openai import ChatOpenAI
from typing import Union
import os, json
from dotenv import load_dotenv

load_dotenv("src/interview/.env")

import re

_HANGUL = re.compile(r"[가-힣]")

def normalize_language(lang: str | None) -> str:
    if not lang:
        return "KOREAN"
    L = str(lang).strip().upper()
    if L in {"EN", "ENGLISH", "EN-US", "EN-GB"}:
        return "ENGLISH"
    if L in {"KO", "KOREAN", "KOR"}:
        return "KOREAN"
    return "KOREAN"

def system_rule(language: str) -> str:
    if language == "ENGLISH":
        return ("You are an interviewer. Use ONLY English. "
                "Output exactly ONE sentence with no preface, numbering, quotes, or explanations. "
                "Ask a specific question about ONE of: core role competencies, recent work, a project, "
                "or a problem the candidate solved. Do not repeat or closely paraphrase the previous question.")
    return ("너는 면접관이다. 오직 한국어만 사용한다. "
            "출력은 정확히 한 문장. 머리말/번호/따옴표/설명 금지. "
            "직무 핵심 역량·최근 업무·프로젝트·문제 해결 중 하나를 구체적으로 묻기. "
            "직전 질문을 반복하거나 비슷하게 바꾸지 말 것.")

def enforce_language_ok(text: str, target: str) -> bool:
    if target == "ENGLISH":
        return not _HANGUL.search(text or "")
    if target == "KOREAN":
        return bool(_HANGUL.search(text or ""))
    return True

# LLM 설정       
llm = ChatOpenAI(
    openai_api_key=os.getenv("OPENAI_API_KEY"),
    base_url="https://api.groq.com/openai/v1",
    model="llama3-8b-8192",
    temperature=0.7
)

def safe_parse_json_from_llm(content: str) -> dict:
    print("📨 [LLM 응답 원문]:", content)
    
    try:
        cleaned = content.strip().replace("```json", "").replace("```", "").strip()
        print("🧼 [클린된 문자열]:", cleaned)

        parsed = json.loads(cleaned)

        if isinstance(parsed, dict):
            print("✅ [JSON 파싱 성공]:", parsed)
            return parsed
        else:
            print("❌ [파싱은 됐지만 dict 아님]:", parsed)
            return {}

    except Exception as e:
        print("❌ [JSON 파싱 예외]:", str(e))
        return {}
type_rule_map = {
    "tech": "- 기술적인 깊이를 평가할 수 있는 질문을 포함할 것",
    "behavior": "- 행동 및 가치관을 평가할 수 있는 질문을 포함할 것",
    "mixed": "- 기술과 인성을 모두 평가할 수 있는 질문을 포함할 것"
}
def get_type_rule(state):
    return type_rule_map.get(state.interviewType, "")

def get_language_rule(lang: str):
    if lang == "KOREAN":
        return "출력은 반드시 한국어로만 작성하세요."
    elif lang == "ENGLISH":
        return "Output must be written in English only."
    else:
        return ""

def router_node(state: InterviewState) -> str:
    if not state.answer:
        print("🧭 [router_node] 첫 질문 생성 흐름")
        return "first_question"
    else:
        print("🧭 [router_node] 답변 분석 흐름")
        return "answer"
    
def set_options_node(state: InterviewState) -> InterviewState:
    """🛠 면접 옵션(language, level, count, interviewType) 확정 노드"""
    if isinstance(state, dict):
        state = InterviewState(**state)

    print("\n======================")
    print("⚙️ [set_options_node] 옵션 설정 시작")
    print(f"입력 language: {state.language}, level: {state.level}, count: {state.count}, interviewType: {state.interviewType}")
    print("======================")

    # 기본값 처리 (명세서 값 그대로 사용)
    if not state.language:
        state.language = "KOREAN"        # 명세서 기준
    if not state.level:
        state.level = "중"               # 명세서 기준 (상/중/하)
    if state.count is None:
        state.count = 0                  # 0이면 동적 모드
    if not state.interviewType:
        state.interviewType = "MIXED"   # 기본값 (명세서에 맞춰 사용)

    # 잠금
    state.options_locked = True

    print(f"✅ 최종 language: {state.language}, level: {state.level}, count: {state.count}, interviewType: {state.interviewType}")
    return state

def build_prompt(state: InterviewState):
    lang_sys = "한국어로 질문하세요." if state.language == "KOREAN" else "Ask in English."
    diff_rule = {
        "하": "개념 확인 위주로, 용어를 풀어서 묻고 힌트를 제공하세요.",
        "중": "직무 관련 구체 질문과 간단한 꼬리질문을 포함하세요.",
        "상": "모호성 허용, 반례·트레이드오프, 시스템 설계/깊은 CS 질문을 우선하세요."
    }[state.level]
    system = f"{lang_sys}\n질문 난이도: {state.level}\n규칙: {diff_rule}"
    return ChatPromptTemplate.from_messages([
        ("system", system),
        ("human", "{context}")
    ])
    
def first_question_node(state: InterviewState) -> InterviewState:
    print("✅ state.raw:", state.model_dump() if hasattr(state, "model_dump") else state)
    """🎯 첫 질문 생성 노드 (interviewId만 사용)"""
    try:
        if isinstance(state, dict):
            state = InterviewState(**state)

        # --- 입력 정리 ---
        job = (getattr(state, "job", "") or "").strip()
        if not job or job.lower() in {"string", "null"}:
            print("⚠️ [경고] 직무 정보 누락 → 기본값 '웹 개발자' 적용")
            state.job = job = "웹 개발자"

        resume_text = (
            getattr(state, "ocrText", None)
            or getattr(state, "resume", "")
            or ""
        ).strip()
        resume_text = resume_text[:1200]  # 토큰 절약 (필요시 조절)

        lang_code = getattr(state, "language", "KOREAN")
        lang = "한국어" if lang_code == "KOREAN" else "영어"

        print("\n======================")
        print("🎯 [first_question_node] 진입")
        print(f"💼 지원 직무: {job}")
        print(f"📄 이력서 텍스트 미리보기: {resume_text[:100] if resume_text else '❌ 없음'}")
        print("======================")

        # --- interviewId (명세 준수: camelCase만) ---
        interviewId = getattr(state, "interviewId", None)
        if not interviewId:
            raise ValueError("❌ interviewId가 없습니다. (명세: interviewId)")

        # --- 프롬프트 (이력서 없어도 직무/경력만으로 질문 생성) ---
        prompt = ChatPromptTemplate.from_messages([
            ("system",
             "너는 기술 면접관이다. 제공된 입력만 사용해 첫 질문을 만든다. "
             "자기소개서가 비어 있으면 직무/경력만으로 질문을 생성한다. "
             f"출력은 {lang}로 된 정확히 한 문장. 머리말/번호/따옴표/설명 금지. "
             "막연한 '자기소개' 금지, 역할의 핵심 역량·최근 업무·프로젝트·문제 해결 중 하나를 구체적으로 묻기."),
            ("system", system_rule(lang_code)),
            ("system", f"{get_type_rule(state)}"),
            ("user", "job: {job}\ncareer: {career}\nresume: '''{resume}'''"),
        ])

        variables = {
            "job": job,
            "career": getattr(state, "career", None) or "미기재",
            "resume": resume_text,  # 빈 문자열이어도 전달
        }

        # --- LLM 실행 ---
        try:
            chain = prompt | llm.bind(max_tokens=64, temperature=0.4, top_p=0.9)
        except AttributeError:
            chain = prompt | llm

        print("🧠 [LLM 요청 시작]")
        response = chain.invoke(variables)
        question = response.content.strip() if hasattr(response, "content") else str(response).strip()
        # 언어 미스매치 보정 (first)
        if not enforce_language_ok(question, lang_code):
            strong = "Respond ONLY in English. One sentence only." if lang_code == "ENGLISH" else "오직 한국어로 한 문장만 답하라."
            fix_prompt = ChatPromptTemplate.from_messages([
                ("system", strong),
                ("user", "Rewrite as a single interview question: '''{q}'''")
            ])
            question = ((fix_prompt | llm).invoke({"q": question}).content).strip()


        # --- 후처리: 한 문장 보장 ---
        if "\n" in question:
            question = question.splitlines()[0].strip()
        if question.count("?") > 1:
            question = question.split("?")[0].strip() + "?"
        if not question:
            question = (
                f"{job} 역할에서 최근 수행한 프로젝트와 본인 기여를 구체적으로 설명해 주세요."
                if lang_code == "KOREAN"
                else f"For the {job} role, describe your most recent project and your specific contribution."
            )

        print("📨 [생성된 질문]:", question)

        # ✅ seq 설정(첫 질문이면 1)
        seq = int(getattr(state, "seq", 0) or 1)
        state.seq = seq

        # (선택) 첫 질문에서만 기존 기록 초기화
        if seq == 1:
            reset_interview(interviewId)

        # ✅ 질문 저장
        save_question(
            interviewId,
            seq,
            question,
            job=getattr(state, "job", None),
            level=getattr(state, "level", None),
            language=getattr(state, "language", None),
        )

        # 상태 업데이트
        if not getattr(state, "question", None):
            state.question = []
        state.question.append(question)
        state.step = (getattr(state, "step", 0) or 0) + 1

        # 종료 판단
        if getattr(state, "count", None) and len(state.question) >= state.count:
            state.is_finished = True
        elif not getattr(state, "count", None) and len(state.question) >= 20:
            state.is_finished = True

        return state

    except Exception as e:
        print("❌ [first_question_node 오류 발생]:", str(e))
        import traceback; traceback.print_exc()
        raise e
    

def answer_node(state: InterviewState) -> Union[InterviewState, None]:
    """답변 수집 노드 - 사용자 입력을 기다리는 상태"""

    if isinstance(state, dict):
        state_obj = InterviewState(**state)
    else:
        state_obj = state

    print("✍️ [answer_node] 사용자 답변 대기 중...")
    print(f"❓ 현재 질문: {state_obj.question[-1] if state_obj.question else 'None'}")
    print(f"📦 [answer_node 리턴 타입]: {type(state_obj)} / 값: {state_obj}")

    # ❗ 답변이 없으면 FSM 종료 (나중에 이어서 실행해야 함)
    if not state_obj.last_answer:
        print("🛑 [answer_node] 답변이 없어 FSM 종료 → 외부 입력 대기")
        return None
     
    question = state_obj.question[-1] if state_obj.question else "질문 없음"
    interviewId = getattr(state_obj, "interviewId", None) or getattr(state_obj, "interviewId", None)
    if not interviewId:
        raise ValueError("interviewId 없음(state_obj.interviewId / interviewId 확인)")

    seq = int(getattr(state_obj, "seq", 0) or 1)   # 현재 질문 번호(답변은 같은 seq로 저장)
    ans_text = (state_obj.last_answer or "").strip()

    save_answer(
        interviewId,
        seq,
        ans_text,  # ← answer 본문
        job=getattr(state_obj, "job", None),
        level=getattr(state_obj, "level", None),
        language=getattr(state_obj, "language", None) or getattr(state_obj, "language", None),
        )


    # ✅ 답변이 있는 경우: 정상 진행
    print("✅ [answer_node] 답변 수신됨 → 다음 단계로")
    state_obj.answer.append(state_obj.last_answer)
    #state_obj.step += 1
    return state_obj

def analyze_node(state: InterviewState) -> InterviewState:
    """🧠 답변 분석 노드"""
    try:
        # ✅ Pydantic 모델 보장
        if isinstance(state, dict):
            state = InterviewState(**state)

        print("\n======================")
        print("🔍 [analyze_node] 진입")
        print("======================")

        # ✅ 분석할 답변 가져오기
        answer = state.last_answer or (state.answer[-1] if state.answer else "")
        if not answer:
            print("⚠️ [경고] 분석할 답변이 없음")
            state.last_analysis = {"comment": "답변이 없어 분석할 수 없습니다."}
            #state.step += 1
            return state

        print("📝 [분석 대상 답변]:", answer[:100], "...")

        # ✅ 프롬프트 구성
        prompt = ChatPromptTemplate.from_messages([
            ("system", """
        너는 면접 평가자입니다. 아래의 답변을 분석해서 '잘한 점', '개선이 필요한 점', '점수(0~100)'를 각각 하나씩 도출하세요. 다른 말은 절대 하지말고,
        형식은 꼭 다음 JSON 형식으로만 한국어로 출력하세요. 잘한 점이 없어도 잘한 점은 꼭 작성해주세요.:
        {{
        "good": "잘한 점",
        "bad": "개선이 필요한 점",
        "score": 점수숫자
        }}
        """),
            ("human", "답변: {answer}")
            ])
        chain = prompt | llm

        # ✅ LLM 분석 요청
        print("🔍 [LLM 요청 시작]")
        response = chain.invoke({"answer": answer})
        print("📨 [LLM 응답 원문]:", response.content)

        # ✅ JSON 파싱 시도
        analysis_json = safe_parse_json_from_llm(response.content)
        if not analysis_json or not isinstance(analysis_json, dict):
            print("❌ [예외 경고] 분석 결과가 None 또는 dict 아님 →", analysis_json)
            analysis_json = {}
        

        # ✅ 상태에 저장
        state.last_analysis = {
            "good": analysis_json.get("good", ""),
            "bad": analysis_json.get("bad", ""),
            "score": analysis_json.get("score", 0)
        }

    except Exception as e:
        print("❌ [analyze_node 오류]:", str(e))
        import traceback
        traceback.print_exc()
        state.last_analysis = {"comment": f"분석 중 오류 발생: {str(e)}"}

    #state.step += 1
    return state


def next_question_node(state: InterviewState) -> InterviewState:
    """➡️ 다음 질문 생성 노드 (interviewId)"""
    if isinstance(state, dict):
        state = InterviewState(**state)

    try:
        # 종료 조건
        if getattr(state, "count", None) and len(state.question) >= state.count:
            state.is_finished = True
            print("🏁 질문 종료 (count 상한 도달)")

        # --- 입력 정리 ---
        job = (getattr(state, "job", "") or "").strip() or "웹 개발자"
        lang_code = getattr(state, "language", "KOREAN")
        lang = "한국어" if lang_code == "KOREAN" else "영어"

        previous_answer = (
            getattr(state, "last_answer", None)
            or (state.answer[-1] if getattr(state, "answer", None) else "")
            or ""
        )
        resume_text = (getattr(state, "ocrText", "") or "").strip()[:1200]
        prev_question = state.question[-1] if getattr(state, "question", None) else ""

        print("📝 [LLM 입력 준비] prev_answer:", previous_answer[:120] if previous_answer else "❌ 없음")
        print("📄 [LLM 입력 준비] resume:", "있음" if resume_text else "없음")
        print("❓ [LLM 입력 준비] prev_question:", prev_question[:120] if prev_question else "❌ 없음")

        # --- interviewId (명세 준수: camelCase만) ---
        interviewId = getattr(state, "interviewId", None)
        if not interviewId:
            raise ValueError("interviewId가 없습니다. (명세: interviewId)")

        # --- 프롬프트 (간결/집중) ---
        question_prompt = ChatPromptTemplate.from_messages([
            ("system",
             "너는 면접관이다. 제공된 정보만 사용해 다음 질문을 만든다. "
             f"출력은 {lang}로 된 정확히 한 문장. 머리말/번호/따옴표/설명 금지. "
             "막연한 일반 질문 금지, 직무 관련 핵심 역량·최근 업무·프로젝트·문제 해결 중 하나를 구체적으로 묻기. "
             "직전 질문과 유사하거나 반복되지 않게 할 것."),
            ("system", system_rule(lang_code)),
            ("system", f"{get_type_rule(state)}"),
            ("user",
             "job: {job}\n"
             "prev_question: {prev_question}\n"
             "prev_answer: '''{prev_answer}'''\n"
             "resume: '''{resume}'''")
        ])

        # --- 생성 파라미터 ---
        try:
            gen = question_prompt | llm.bind(max_tokens=64, temperature=0.5, top_p=0.9)
        except AttributeError:
            gen = question_prompt | llm

        max_attempts = int(getattr(state, "retry_max", 3) or 3)
        attempt = 0
        next_q = None
        candidate_q = ""
        cur_seq = int(getattr(state, "seq", 0) or 1)

        while attempt < max_attempts:
            payload = {
                "job": job,
                "prev_question": prev_question,
                "prev_answer": previous_answer,
                "resume": resume_text,  # 비어 있어도 전달 → LLM이 직무/답변만으로 생성
            }
            print(f"🧠 [LLM 요청] 시도 {attempt+1}/{max_attempts}")
            result = gen.invoke(payload)
            candidate_q = result.content.strip() if hasattr(result, "content") else str(result).strip()

            # 후처리: 한 문장/첫 줄
            if "\n" in candidate_q:
                candidate_q = candidate_q.splitlines()[0].strip()
            if candidate_q.count("?") > 1:
                candidate_q = candidate_q.split("?")[0].strip() + "?"
            if not candidate_q.endswith((".", "?", "!")):
                candidate_q += "?"

            print(f"🧪 [시도 {attempt+1}] 후보 질문: {candidate_q}")

            # ✅ 유사 질문 확인
            try:
                check = get_similar_question(
                    interviewId=interviewId,
                    question=candidate_q,
                    k=5,
                    min_similarity=0.88,
                    verify_all=True,
                )
                if not check.get("similar"):
                    next_q = candidate_q
                    break
                else:
                    top3 = ", ".join(f"{h['sim']:.3f}" for h in (check.get("hits") or [])[:3])
                    print(
                        f"❌ 유사 질문 존재 (sim={check.get('top_sim', 0):.3f}, via {check.get('method', '-')})"
                        + (f" | knn top3: {top3}" if top3 else "")
                        + f" | 매칭: {(check.get('match') or '')[:120]}"
                    )
            except Exception as e:
                print("⚠️ 유사도 검사 실패(통과 처리):", str(e))
                next_q = candidate_q
                break

            attempt += 1

        # 🔚 재시도 실패 시 fallback
        if not next_q:
            next_q = candidate_q if candidate_q else (
                f"{job} 역할에서 방금 답변하신 내용 중 가장 큰 도전 과제와 해결 과정을 구체적으로 설명해 주세요."
                if lang_code == "KOREAN"
                else f"For the {job} role, based on your last answer, describe the biggest challenge you faced and how you solved it."
            )
            print("⚠️ 재시도 실패 → 폴백 질문 사용:", next_q)

        # ✅ seq + 1 하고 DB에 '질문' 저장
        state.seq = cur_seq + 1
        save_question(
            interviewId=interviewId,
            seq=state.seq,
            question=next_q,
            job=getattr(state, "job", None),
            level=getattr(state, "level", None),
            language=getattr(state, "language", None),
        )

        # 상태 갱신
        if not getattr(state, "question", None):
            state.question = []
        state.question.append(next_q)
        print(f"➡️ 질문 {len(state.question)} 생성 완료: {next_q}")

        # 종료 판단
        if getattr(state, "count", None) and len(state.question) >= state.count:
            state.is_finished = True
        elif not getattr(state, "count", None) and len(state.question) >= 20:
            state.is_finished = True

    except Exception as e:
        print("❌ [next_question_node 예외 발생]:", str(e))
        import traceback; traceback.print_exc()
        state.is_finished = True

    state.step = getattr(state, "step", 0) + 1
    return state
